﻿
using var game = new Font_Repacker.Game1();
game.Run();
