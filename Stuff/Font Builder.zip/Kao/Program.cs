﻿
using var game = new Kao.Game1();
game.Run();
